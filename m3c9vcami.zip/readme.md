navbar 

carrito de compra  
boton de wsp fijo al hacer scroll
aviso de mensaje ¡Envíos gratis por compras sobre $30.000! 🐾 en header que se mueva 

hero en proceso- 

fondo backgroud de perritos  

Aviso de agregado a tu carrito
mensajes tipo toast

imagenes de productos lo mas buscado (modo carrusel)
imagenes de productos variados (cards para carrito )


Formulario de contacto 
tablon de opiniones de clientes.

footer que debe contener
boton de retorno listo 
direccion listo 
redes sociales 
horario 
mapa ubicación
