navbar 

carrito de compra  verificar que productos digan cantidades , que no se cierre mientras eliminamos productos de golpe , unicamente cuando hacemos click en x 

boton de wsp fijo al hacer scroll

aviso de mensaje ¡Envíos gratis por compras sobre $30.000! 🐾 en header que se mueva listo


hero en proceso- casi listo 

fondo backgroud de perritos  listo 

Aviso de agregado a tu carrito listo 
mensajes tipo toast listo 

imagenes de productos lo mas buscado (modo carrusel)
imagenes de productos variados (cards para carrito ) falta 


Formulario de contacto   falta editar y reestructurar 
tablon de opiniones de clientes. falta editar y reestructurar 

footer que debe contener
boton de retorno listo  listo 
direccion listo   listo 
redes sociales    listo 
horario           listo 
mapa ubicación     organizar para que se vea que es en santiago de forma generica 
